package edu.innova.test;


import java.sql.SQLException;


public class UsuarioServicioTest {

    public static void main(String[] args) throws SQLException {
        
        
 
       

    }

}
