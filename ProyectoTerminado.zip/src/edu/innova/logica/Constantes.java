package edu.innova.logica;

public class Constantes {

    public static final String ARTISTA = "artista";
    public static final String ESPECTADOR = "espectador";

}
